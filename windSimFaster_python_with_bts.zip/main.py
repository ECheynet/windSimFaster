#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Python tutorial for windSimFaster.

Updated to follow the MATLAB documentation and diagnostics.
"""

import numpy as np
import matplotlib.pyplot as plt
from time import time
from scipy.signal import welch, detrend
from scipy.interpolate import interp1d

from myFunctions import get_sampling_para, random_process, KaimalModel, windSimFaster, write2bts

#%% Time and frequency definitions
np.random.seed(1)  # for reproducibility only
fs = 2  # sampling frequency (Hz)
M = 15  # number of time steps = 2**M
t, f = get_sampling_para(M, fs)
N, Nfreq = len(t), len(f)
dt = np.median(np.diff(t))

#%% Grid definition
Nyy, Nzz = 2, 5
ymin, ymax = -120, 120
zmin, zmax = 10, 280
y = np.linspace(ymin, ymax, Nyy)
z = np.linspace(zmin, zmax, Nzz)
Y, Z = np.meshgrid(y, z)
Nnodes = Z.size

#%% Mean wind speed profile
u_star = 0.8  # friction velocity (m/s)
kappa = 0.4  # von Karman constant
z0 = 0.01  # roughness length
log_profile = lambda u_star, z, z0, kappa: u_star / kappa * np.log(z / z0)
meanU = log_profile(u_star, Z, z0, kappa)

#%% Generate uncorrelated wind velocity histories
start_time = time()
u = np.zeros((N, Nnodes)); v = np.zeros_like(u); w = np.zeros_like(u)
Su = np.zeros((Nfreq, Nnodes)); Sv = np.zeros_like(Su); Sw = np.zeros_like(Su)
dummyU, dummyZ = meanU.ravel(), Z.ravel()
for ii in range(Nnodes):
    Su_i, Sv_i, Sw_i = KaimalModel(dummyU[ii], dummyZ[ii], f, u_star)[:3]
    Su[:, ii], Sv[:, ii], Sw[:, ii] = Su_i.ravel(), Sv_i.ravel(), Sw_i.ravel()
    u[:, ii], _ = random_process(f, Su[:, ii]); v[:, ii], _ = random_process(f, Sv[:, ii]); w[:, ii], _ = random_process(f, Sw[:, ii])
print(f"Uncorrelated histories: {time() - start_time:.2f} s")

#%% Introduce spatial correlation
Cuy, Cuz = 10, 12
Cvy, Cvz = 10, 12
Cwy, Cwz = 5, 6
start_time = time()
u_corr = windSimFaster(Y, Z, meanU, Cuy, Cuz, f, u).reshape(N, Nzz, Nyy)
v_corr = windSimFaster(Y, Z, meanU, Cvy, Cvz, f, v).reshape(N, Nzz, Nyy)
w_corr = windSimFaster(Y, Z, meanU, Cwy, Cwz, f, w).reshape(N, Nzz, Nyy)
u_corr += meanU[None, :, :]  # mean wind speed is added only to u
print(f"Spatial correlation: {time() - start_time:.2f} s")

Su_grid = Su.reshape(Nfreq, Nzz, Nyy); Sv_grid = Sv.reshape(Nfreq, Nzz, Nyy); Sw_grid = Sw.reshape(Nfreq, Nzz, Nyy)

#%% Time series visualization
indEnd = np.argmin(np.abs(t - 300)) + 1
iz = np.arange(0, min(Nzz, 6), 2)
fig, axs = plt.subplots(3, 1, sharex=True, figsize=(8, 7))
for ax, x, lab in zip(axs, [u_corr, v_corr, w_corr], ['u', 'v', 'w']):
    ax.plot(t[:indEnd], x[:indEnd, iz, 0]); ax.set_ylabel(f'{lab} (m s$^{{-1}}$)'); ax.grid(True); ax.set_xlim(0, 300)
axs[-1].set_xlabel('time (s)'); fig.tight_layout()

#%% Mean wind speed profile
fig, ax = plt.subplots()
ax.plot(np.mean(u_corr[:, :, 0], axis=0), z, 'ko', markerfacecolor='r', label='Computed')
z1 = np.logspace(np.log10(z[0]), np.log10(z[-1]), 60)
ax.plot(log_profile(u_star, z1, z0, kappa), z1, 'b', label='Target')
ax.set_xlabel('meanU (m s$^{-1}$)'); ax.set_ylabel('Height above ground (m)'); ax.grid(True); ax.legend(); fig.tight_layout()

#%% Standard deviation profiles
df = f[0]
sigSim = np.vstack([np.std(u_corr[:, :, 0], axis=0), np.std(v_corr[:, :, 0], axis=0), np.std(w_corr[:, :, 0], axis=0)])
sigTarget = np.sqrt(df * np.vstack([np.sum(Su_grid[:, :, 0], axis=0), np.sum(Sv_grid[:, :, 0], axis=0), np.sum(Sw_grid[:, :, 0], axis=0)]))
fig, axs = plt.subplots(1, 3, sharey=True, figsize=(10, 5))
for ii, (ax, comp) in enumerate(zip(axs, ['u', 'v', 'w'])):
    ax.plot(sigSim[ii], z, 'ko', markerfacecolor='r', linestyle='none', label='Simulated'); ax.plot(sigTarget[ii], z, 'b', linewidth=1.5, label='Target')
    ax.set_xlabel(rf'$\sigma_{comp}$ (m s$^{{-1}}$)'); ax.set_title(comp); ax.grid(True); ax.margins(x=0.05)
axs[0].set_ylabel('Height above ground (m)'); axs[1].legend(loc='lower center', bbox_to_anchor=(0.5, 1.08), ncol=2); fig.tight_layout()
print('Maximum relative error in standard deviation:')
for ii, comp in enumerate(['u', 'v', 'w']): print(f"  {comp}: {100*np.max(np.abs(sigSim[ii]-sigTarget[ii])/sigTarget[ii]):.2f}%")

#%% Pseudocolor plots
indEnd = np.argmin(np.abs(t - 450)) + 1
fig, axs = plt.subplots(6, 1, figsize=(10, 12), sharex=True)
for jj, (field, comp) in enumerate(zip([u_corr, v_corr, w_corr], ['u', 'v', 'w'])):
    im = axs[2*jj].imshow(field[:indEnd, :, 0].T, aspect='auto', origin='lower', extent=[t[0], t[indEnd-1], z.min(), z.max()]); axs[2*jj].set_ylabel('z (m)'); fig.colorbar(im, ax=axs[2*jj], label=f'{comp} (m s$^{{-1}}$)')
    im = axs[2*jj+1].imshow(field[:indEnd, 0, :].T, aspect='auto', origin='lower', extent=[t[0], t[indEnd-1], y.min(), y.max()]); axs[2*jj+1].set_ylabel('y (m)'); fig.colorbar(im, ax=axs[2*jj+1], label=f'{comp} (m s$^{{-1}}$)')
axs[-1].set_xlabel('time (s)'); fig.tight_layout()

#%% Power spectral density
indZ = np.argmin(np.abs(z - 50))
nperseg = round(N / 8); noverlap = round(nperseg / 2)
P = []
for field in [u_corr, v_corr, w_corr]:
    f0, Pi = welch(detrend(field[:, indZ, 0]), fs=fs, nperseg=nperseg, noverlap=noverlap, window='hamming'); P.append(Pi)
fr0 = z[indZ] / meanU[indZ, 0] * f0; fr = z[indZ] / meanU[indZ, 0] * f
fig, ax = plt.subplots()
for Pi, comp in zip(P, ['u', 'v', 'w']): ax.loglog(fr0[1:], f0[1:] * Pi[1:] / u_star**2, label=f'i={comp}')
for Si in [Su_grid[:, indZ, 0], Sv_grid[:, indZ, 0], Sw_grid[:, indZ, 0]]: ax.loglog(fr, f * Si / u_star**2, 'k', linewidth=1)
ax.set_xlabel('f z / U'); ax.set_ylabel(r'$fS_i/u_*^2$'); ax.grid(True, which='both'); ax.legend(); ax.set_xlim(fr0[1], fr0[-1]); fig.tight_layout()

#%% Saving data into a bts file
zHub, ntower, fname = 150, 0, 'testFile.bts'
z1, z_out, y_out = Z[:, 0].copy(), Z[:, 0].copy(), Y[0, :].copy()
u_out, v_out, w_out = u_corr.copy(), v_corr.copy(), w_corr.copy()
if z_out[0] > z_out[-1]:
    z_out = z_out[::-1]; u_out = np.flip(u_out, axis=1); v_out = np.flip(v_out, axis=1); w_out = np.flip(w_out, axis=1)
uHub = interp1d(z1, meanU[:, 0], kind='linear', fill_value='extrapolate')(zHub)
write2bts(fname, u_out, v_out, w_out, t, y_out, z_out, zHub, uHub, ntower)

plt.show()
