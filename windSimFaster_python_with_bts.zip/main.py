#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jun 26 13:56:34 2024

@author: ech022
"""

import numpy as np
import matplotlib.pyplot as plt
from time import time
from scipy.signal import welch, detrend
from scipy import integrate

from myFunctions import get_sampling_para, random_process, KaimalModel, windSimFaster, write2bts

#%%

# Script starts here
np.random.seed(1)  # for reproducibility

# Parameters setup
fs = 2 # sampling frequency in Hertz
M = 15  # M is the power of 2

# Generate sampling parameters
t, f = get_sampling_para(M, fs)
N = len(t)  # number of time steps
Nfreq = len(f)  # number of frequency steps
dt = np.median(np.diff(t))  # time step

# Grid definition
Nyy = 2  # number of nodes along the y axis
Nzz = 5  # number of nodes along the z axis
ymin, ymax = -120, 120
zmin, zmax = 10, 280
y = np.linspace(ymin, ymax, Nyy)
z = np.linspace(zmin, zmax, Nzz)
Y, Z = np.meshgrid(y, z)
M = np.size(Z)

# Mean wind speed profile
u_star = 0.8  # Friction velocity (m/s)
kappa = 0.4  # von Karman constant
z0 = 0.01  # roughness length

def log_profile(u_star, z, z0, kappa):
    return u_star / kappa * np.log(z / z0)

meanU = log_profile(u_star, Z, z0, kappa)

# Generate uncorrelated wind velocity histories
start_time = time()
Nf = len(f)
u = np.zeros((N, M))
Su = np.zeros((Nf, M))
dummyU = meanU.ravel()
dummyZ = Z.ravel()

for ii in range(M):
    Su[:, ii] = KaimalModel(dummyU[ii], dummyZ[ii], f, u_star)[0]
    u[:, ii], _ = random_process(f, Su[:, ii])

print(f"Elapsed time {time() - start_time:.2f} s")


# Calculate the target standard deviation from the PSD
stdU_target = np.sqrt(np.trapz(Su[:, 1], f))

# Calculate the simulated standard deviation from the time series
stdU_simulated = np.std(u[:, 1])  # Assuming you want the std dev for the same index as Su

print(f"Target Standard Deviation {stdU_target:.2f} m/s")
# Calculate and print the relative difference between the simulated and target standard deviations
relative_error = 100 * (stdU_simulated - stdU_target) / stdU_target
print(f"The relative error is {relative_error:.2f}%")

#%% Compute PSD for the uncorrelated wind field
import scipy.signal

# Calculate segment size and overlap
nperseg = round(N / 4)
noverlap = round(N / 8)
# Determine the number of frequency bins
freq_bins = nperseg // 2 + 1
# Preallocate psd_u
psd_u = np.zeros((freq_bins, M))
# Compute PSD for each node and store in preallocated array
plt.figure(figsize=(10, 6))
for ii in range(M):
    freqs_welch, psd_u[:, ii] = scipy.signal.welch(u[:, ii], fs, nperseg=nperseg, noverlap=noverlap, window='hamming')
    
freqs_welch[0]=np.nan
plt.figure(figsize=(10, 6))
plt.loglog(freqs_welch, freqs_welch*psd_u[:, ii]/ u_star**2, label=f'Height = {np.linspace(zmin, zmax, M)[ii]:.2f} m')
plt.loglog(f, f*Su[:, ii]/ u_star**2, label='Kaimal model')
plt.xlabel('Frequency (Hz)')
plt.ylabel('Power Spectral Density')
plt.title('Power Spectral Density (PSD) of Random Process u')
plt.legend(title="Node Heights")
plt.grid(True, which="both", ls="-")


#%% Introduce correlation

# Constants
Cy = 5  # Davenport coherence coefficient for lateral separations
Cz = 5 # Davenport coherence coefficient for vertical separations

start_time = time()
u_corr = windSimFaster(Y, Z, meanU, Cy, Cz, f, u)
u_corr = u_corr.reshape((N, Nzz, Nyy))

print(f"Elapsed time {time() - start_time:.2f} s")

#%%


# Assuming t, z, y, and u_corr are already defined
# Find the index where t is closest to 450
indEnd = np.argmin(np.abs(t - 450))

# Create the figure and axes
fig, axs = plt.subplots(2, 1, figsize=(14, 5))
fig.subplots_adjust(hspace=0.1)  # Adjust horizontal space if needed

# First subplot
im1 = axs[0].imshow(u_corr[1:indEnd, :, 1].T, aspect='auto', origin='lower', 
                    extent=[t[0], t[indEnd], z.min(), z.max()])
axs[0].set_ylabel('z (m)')
axs[0].set_xticklabels([])  # Hide x tick labels for the top plot
cbar1 = fig.colorbar(im1, ax=axs[0])
cbar1.set_label('u (m/s)')

# Second subplot
im2 = axs[1].imshow(u_corr[1:indEnd, 1, :].T, aspect='auto', origin='lower',
                    extent=[t[0], t[indEnd], y.min(), y.max()])
axs[1].set_ylabel('y (m)')
axs[1].set_xlabel('time (s)')
cbar2 = fig.colorbar(im2, ax=axs[1])
cbar2.set_label('u (m/s)')

# Set global figure properties
fig.patch.set_facecolor('white')
for ax in axs:
    ax.tick_params(labelsize=10)  # Set tick parameters for all axes
    ax.set_xlim([t[0], t[indEnd]])  # Tighten x-axis limits



#%%

# Assuming Z, u_corr, N, fs, u_star, meanU, and Su are already defined

# Find index closest to Z = 50 in the first column of Z
indZ = np.argmin(np.abs(Z[:, 0] - 280))

# Set parameters for Welch's method
nperseg = round(N /4)  # Number of points for each segment
noverlap = round(nperseg / 2)  # 50% overlapping

# Compute PSD using Welch's method
f0, Su0 = welch(detrend(np.squeeze(u_corr[:, indZ, 0])), fs=fs, nperseg=nperseg, noverlap=noverlap, window='hamming')
f0[0] = np.nan

# Adjust PSD for plotting
Su0 = f0 * Su0 / u_star**2
fr0 = Z[indZ, 0] / meanU[indZ, 0] * f0

# Frequency normalization for original Su
fr = Z[indZ, 0] / meanU[indZ, 0] * f
coeff = f / u_star**2

Su_target = KaimalModel(meanU[indZ, 0], Z[indZ, 0], f, u_star)[0]

# Plotting
plt.figure()
plt.loglog(fr0, Su0, 'b', label='Welch PSD')
plt.loglog(fr, coeff * Su_target[0,:], 'k', label='Target')
plt.xlabel('fz / U')
plt.ylabel('fS_u / u_*^2')
plt.axis('tight')
plt.grid(True)
plt.legend()
plt.gca().set_facecolor('w')



#%%

u = np.reshape(u, (N, Nzz, Nyy))

from scipy.interpolate import interp1d

# Initial variable setup
zHub = 150
ntower = 0
fname = 'testFile.bts'

# Assuming Z and Y are defined somewhere else in your program
z1 = Z[:, 0]
z = Z[:, 0]
y = Y[0, :].reshape(-1)

# Handle the potential absence of 'v' and 'w'
if 'v' not in locals():
    v = np.copy(u)  # Simplify by writing v = u (copy to avoid referencing the same array)
if 'w' not in locals():
    w = np.copy(u)  # Simplify by writing w = u (copy to avoid referencing the same array)

# Flip arrays if the first z-value is greater than the last
if z[0] > z[-1]:
    z = np.flipud(z)
    u = np.flip(u, axis=0)
    v = np.flip(v, axis=0)
    w = np.flip(w, axis=0)

# Interpolate uHub
meanU_interp = interp1d(z1, meanU[:, 0], kind='cubic', fill_value='extrapolate')
uHub = meanU_interp(zHub)

# Call the write function
write2bts(fname, u, v, w, t, y, z, zHub, uHub, ntower)




