#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jun 26 13:56:34 2024

@author: ech022
"""
from numpy.fft import fft, ifft
import numpy as np
import scipy.linalg

def random_process(f, S):
    """
    Generates a random process in the time domain based on a target power spectral density (PSD) S,
    associated with the frequency vector f.
    
    Parameters:
    f: Numpy array of size [1 x Nfreq] of frequency (in Hz)
    S: Numpy array of size [1 x Nfreq] of the target PSD.
    
    Returns:
    u: Numpy array of size [N x 1] representing the random process
    t: Numpy array of size [N x 1] representing the time
    """
    Nfreq = len(f)
    dt = 1 / (2 * f[-1])
    # Compute the core spectral matrix A with random phases and the target PSD
    A = np.sqrt(S) * np.exp(1j * 2 * np.pi * np.random.rand(Nfreq))
    # Apply the IFFT
    Nu = np.concatenate(([0], A[:Nfreq-1], [A[Nfreq-1].real], np.conj(A[:Nfreq-1][::-1])))
    u = np.real(np.fft.ifft(Nu) * np.sqrt(Nfreq / dt))
    t = np.arange(len(u)) * dt
    return u, t

def KaimalModel(U, Z, f, u_star):
    """
    Computes the one-point auto and cross-spectral densities of the Kaimal model.
    
    Parameters:
    U : numpy.ndarray
        2D array of mean wind velocity (in m/s) at each node of a grid.
    Z : numpy.ndarray
        2D array of height (in m) at each node of a grid.
    f : numpy.ndarray
        1D array of frequency (in Hz).
    u_star : float
        Friction velocity (in m/s).

    Returns:
    Su, Sv, Sw, Suw, Svw, Suv : numpy.ndarray
        Arrays corresponding to the PSD of the u, v, w components and CPSD of u-w, v-w, u-v components respectively.
    """
    Nfreq = len(f)
    Nm = U.size
    Su = np.zeros((Nm, Nfreq))
    Sv = np.zeros((Nm, Nfreq))
    Sw = np.zeros((Nm, Nfreq))
    Suw = np.zeros((Nm, Nfreq))
    Svw = np.zeros((Nm, Nfreq))
    Suv = np.zeros((Nm, Nfreq))
    
    dummyU = U.ravel()
    dummyZ = Z.ravel()
    
    for jj in range(Nm):
        fr = (f * dummyZ[jj] / dummyU[jj])
        Su[jj, :] = 102. * fr / (1 + 33. * fr)**(5/3) * u_star**2 / f
        Sv[jj, :] = 17. * fr / (1 + 9.5 * fr)**(5/3) * u_star**2 / f
        Sw[jj, :] = (2. * fr / (1 + 5. * fr)**(5/3)) * u_star**2 / f
        Suw[jj, :] = -14. * fr / (1 + 10.5 * fr)**(7/3) * (0.5 * u_star)**2 / f
        Svw[jj, :] = -14. * fr / (1 + 10.5 * fr)**(7/3) * (0.5 * u_star)**2 / f
        Suv[jj, :] = 14. * fr / (1 + 10.5 * fr)**(7/3) * (0.25 * u_star)**2 / f
        
    return Su, Sv, Sw, Suw, Svw, Suv

def get_sampling_para(M, fs):
    """
    Computes the time and frequency vectors based on the sampling frequency and an integer M used to compute the number of time steps, which is equal to 2^M.
    
    Parameters:
    M : int
        A natural number used as the power of 2 to compute the number of time steps for the simulation.
    fs : float
        Sampling frequency (Hz).
    
    Returns:
    t : numpy.ndarray
        Time vector (units: s).
    f : numpy.ndarray
        Frequency vector (units: s^(-1)).
    """
    if M % 1 != 0 or M <= 0:
        raise ValueError("'M' should be a natural number")
    
    N = 2 ** M  # Number of time steps
    dt = 1 / fs  # Time step size
    tmax = dt * N  # Maximum time
    t = np.arange(0, N) * dt  # Time vector
    
    print(f"Duration of target time series is {tmax / 3600:.3f} hours, i.e. {tmax:.3f} sec\n")
    
    f0 = 1 / tmax  # Minimal frequency recorded
    fc = fs / 2  # Nyquist frequency
    f = np.arange(f0, fc + f0, f0)  # Frequency vector
    
    return t, f

def windSimFaster(Y, Z, U, Cy, Cz, f, u):
    """
    Simulates spatially correlated wind fields over a grid defined by Y and Z coordinates,
    based on mean wind speeds U, Davenport coherence coefficients Cy and Cz, frequency vector f,
    and an array of uncorrelated wind velocities u.

    :param Y: Matrix of y-coordinates (lateral) of grid nodes.
    :param Z: Matrix of z-coordinates (vertical) of grid nodes.
    :param U: Matrix or vector of mean wind speed at each grid node.
    :param Cy: Scalar Davenport coherence coefficient for lateral separations.
    :param Cz: Scalar Davenport coherence coefficient for vertical separations.
    :param f: Vector of frequency steps for the simulation.
    :param u: Matrix of uncorrelated wind velocities.
    :return: Matrix of correlated wind velocities.
    """

    
    # Calculate distances in Y and Z dimensions
    # Calculate distances in Y and Z dimensions using correct broadcasting
    dy = np.abs(Y.flatten()[:, np.newaxis] - Y.flatten()[np.newaxis, :])
    dz = np.abs(Z.flatten()[:, np.newaxis]- Z.flatten()[np.newaxis, :])

    # Calculate mean wind speed between each node
    meanU = 0.5 * (U.flatten()[:, np.newaxis] + U.flatten()[np.newaxis, :])

    # Davenport decay coefficients with lateral and vertical separation
    ay = Cy * dy
    az = Cz * dz

    # Coherence matrix calculation
    K = -np.sqrt(ay**2 + az**2) / meanU

    # Coherence function for Davenport's model
    def cohDavenport(K, f):
        return np.exp(K * f)

    # Create a two-sided frequency array
    Nf = f.shape[0]
    f2s = np.concatenate([[0], f[0:Nf-1]])
    f2s = np.concatenate([f2s, np.flipud(f2s)])

    # Fourier transform of uncorrelated wind velocities
    fftU = fft(u, axis=0)
    N = len(f2s)

    for ii in range(1, N):  # Start from 2 to skip the zero frequency and first bin
        cohU = cohDavenport(K, f2s[ii])
        if np.min(cohU) < 0.99:
            try:
                C = scipy.linalg.cholesky(cohU, lower=True)
            except np.linalg.LinAlgError:  # If Cholesky fails, use LDL decomposition
                L, D, _ = scipy.linalg.ldl(cohU, lower=True)
                C = L @ np.sqrt(D)
            fftU[ii, :] = (C @ (np.exp(1j * np.angle(fftU[ii, :])))) * np.abs(fftU[ii, :])
        else:
            fftU[ii, :] = np.mean(fftU[ii, :])

    # Zero mean value at zero frequency
    fftU[0, :] = 0

    # Convert back to the time domain
    u_corr = np.real(ifft(fftU, axis=0))

    # Add the mean wind speed to each time series
    u_corr += U.ravel()

    return u_corr   
    


def write2bts(filename, u, v, w, t, y, z, zHub, uHub, ntower):
    """
    This function is a first attempt to write output from windSimFast into
    a bts file. The function write2bts is based on the function readTSgrid.m by
    Bonnie Jonkman, National Renewable Energy Laboratory
    Author: E. Cheynet  - UiB - Last modified 28/11/2022
    """
    nffc = 3  # number of velocity components
    nt = u.shape[0]
    ny = len(y)
    nz = len(z)
    dt = np.median(np.diff(t))
    
    dz = abs(np.median(np.diff(z)))
    dy = abs(np.median(np.diff(y)))
    
    coeff = 1000
    
    with open(filename, 'wb') as fid:
        # Headers
        fid.write(np.int16(8).tobytes())        # TurbSim format identifier (E.C.: should = 8 to work on fast.Farm), INT(2)
        fid.write(np.int32(nz).tobytes())        # the number of grid points vertically, INT(4)
        fid.write(np.int32(ny).tobytes())        # the number of grid points laterally, INT(4)
        fid.write(np.int32(ntower).tobytes())        # the number of tower points, INT(4)
        fid.write(np.int32(nt).tobytes())        # the number of time steps, INT(4)
        fid.write(np.float32(dz).tobytes())      # grid spacing in vertical direction, REAL(4), in m
        fid.write(np.float32(dy).tobytes())      # grid spacing in lateral direction, REAL(4), in m
        fid.write(np.float32(dt).tobytes())      # grid spacing in delta time, REAL(4), in m/s
        fid.write(np.float32(uHub).tobytes())      # the mean wind speed at hub height, REAL(4), in m/s
        fid.write(np.float32(zHub).tobytes())      # height of the hub, REAL(4), in m
        fid.write(np.float32(min(z)).tobytes())      # height of the bottom of the grid, REAL(4), in m
        
        fid.write(np.float32(coeff).tobytes())  # the U-component slope for scaling, REAL(4)
        fid.write(np.float32(0).tobytes())      # the U-component offset for scaling, REAL(4)
        fid.write(np.float32(coeff).tobytes())  # the V-component slope for scaling, REAL(4)
        fid.write(np.float32(0).tobytes())      # the V-component offset for scaling, REAL(4)
        fid.write(np.float32(coeff).tobytes())  # the W-component slope for scaling, REAL(4)
        fid.write(np.float32(0).tobytes())      # the W-component offset for scaling, REAL(4)
        
        # Read the description string: "Generated by TurbSim (vx.xx, dd-mmm-yyyy) on dd-mmm-yyyy at hh:mm:ss."
        asciiSTR = 'This full-field file was generated by windSimFaster'.encode('ascii')
        fid.write(np.int32(len(asciiSTR)).tobytes())     # the number of characters in the description string, max 200, INT(4)
        fid.write(asciiSTR)  # the ASCII integer representation of the character string
        print(f'Reading from the file {filename} with heading:')
        print(f'   "{asciiSTR.decode("ascii")}".')
        
        WF = np.zeros((nt, nz, ny, nffc))
        WF[:,:,:,0] = u
        WF[:,:,:,1] = v
        WF[:,:,:,2] = w
        
        val = np.zeros(nffc, dtype=np.int16)
        for it in range(nt):
            for iz in range(nz):
                for iy in range(ny):
                    for ii in range(nffc):
                        val[ii] = np.int16(WF[it, iz, iy, ii] * coeff)
                    fid.write(val.tobytes())
