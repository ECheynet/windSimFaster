#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Python functions for windSimFaster.

Updated from the MATLAB reference implementations supplied by the author.
"""
from numpy.fft import fft, ifft
import numpy as np
import scipy.linalg


def random_process(f, S):
    """Generate a random process with target one-sided PSD ``S`` at frequencies ``f``."""
    f = np.asarray(f).reshape(-1)
    S = np.asarray(S).reshape(-1)
    Nfreq = f.size
    if S.size != Nfreq:
        raise ValueError("f and S must have the same number of elements")
    dt = 1 / (2 * f[-1])
    A = np.sqrt(S) * np.exp(1j * 2 * np.pi * np.random.rand(Nfreq))
    Nu = np.concatenate(([0], A[:-1], [A[-1].real], np.conj(A[:-1][::-1])))
    u = np.real(ifft(Nu) * np.sqrt(Nfreq / dt))
    t = np.arange(u.size) * dt
    return u, t


def KaimalModel(U, Z, f, u_star):
    """Compute the Kaimal auto- and cross-spectral densities."""
    U = np.asarray(U)
    Z = np.asarray(Z)
    f = np.asarray(f).reshape(-1)
    Nfreq = f.size
    Nm = U.size
    Su = np.zeros((Nm, Nfreq))
    Sv = np.zeros((Nm, Nfreq))
    Sw = np.zeros((Nm, Nfreq))
    Suw = np.zeros((Nm, Nfreq))
    Svw = np.zeros((Nm, Nfreq))
    Suv = np.zeros((Nm, Nfreq))
    dummyU = U.reshape(-1)
    dummyZ = Z.reshape(-1)
    for jj in range(Nm):
        fr = f * dummyZ[jj] / dummyU[jj]
        Su[jj, :] = 102. * fr / (1 + 33. * fr)**(5/3) * u_star**2 / f
        Sv[jj, :] = 17. * fr / (1 + 9.5 * fr)**(5/3) * u_star**2 / f
        Sw[jj, :] = 2. * fr / (1 + 5. * fr)**(5/3) * u_star**2 / f
        Suw[jj, :] = -14. * fr / (1 + 10.5 * fr)**(7/3) * (0.5 * u_star)**2 / f
        Svw[jj, :] = -14. * fr / (1 + 10.5 * fr)**(7/3) * (0.5 * u_star)**2 / f
        Suv[jj, :] = 14. * fr / (1 + 10.5 * fr)**(7/3) * (0.25 * u_star)**2 / f
    return Su, Sv, Sw, Suw, Svw, Suv


def get_sampling_para(M, fs):
    """Compute time and positive-frequency vectors for ``N = 2**M`` samples."""
    if M % 1 != 0 or M <= 0:
        raise ValueError("'M' should be a natural number")
    N = 2 ** int(M)
    dt = 1 / fs
    tmax = dt * N
    t = np.arange(N) * dt
    print(f"Duration of target time series is {tmax / 3600:.3g} hours, i.e. {tmax:.3g} sec\n")
    f0 = 1 / tmax
    f = np.arange(1, N // 2 + 1) * f0
    return t, f


def windSimFaster(Y, Z, U, Cy, Cz, f, u, cohmodel='Davenport'):
    """Introduce spatial correlation using the coherence models in the MATLAB implementation."""
    Y, Z, U, f, u = np.asarray(Y), np.asarray(Z), np.asarray(U), np.asarray(f).reshape(-1), np.asarray(u)
    Cy, Cz = np.atleast_1d(Cy), np.atleast_1d(Cz)
    if Y.shape != Z.shape or U.size != Y.size:
        raise ValueError("Y, Z and U must describe the same grid")
    if u.ndim != 2 or u.shape[1] != Y.size:
        raise ValueError("u must have shape (N, Y.size)")
    yv, zv, uv = Y.reshape(-1), Z.reshape(-1), U.reshape(-1)
    dy = np.abs(yv[:, None] - yv[None, :])
    dz = np.abs(zv[:, None] - zv[None, :])
    z_avg = 0.5 * (zv[:, None] + zv[None, :])
    meanU = 0.5 * (uv[:, None] + uv[None, :])
    model = cohmodel.lower()

    if model == 'davenport':
        K = -np.sqrt((Cy[0] * dy)**2 + (Cz[0] * dz)**2) / meanU
        model_fun = lambda freq: np.exp(K * freq)
    elif model == 'bowen':
        if Cy.size < 2 or Cz.size < 2:
            raise ValueError("Bowen requires Cy and Cz with at least two coefficients")
        ay = Cy[0] * dy + Cy[1] * dy**2 / z_avg
        az = Cz[0] * dz + Cz[1] * dz**2 / z_avg
        K = -np.sqrt(ay**2 + az**2) / meanU
        model_fun = lambda freq: np.exp(K * freq)
    elif model == 'bowen2':
        if Cy.size < 3 or Cz.size < 3:
            raise ValueError("Bowen2 requires Cy and Cz with at least three coefficients")
        def model_fun(freq):
            ay = np.sqrt((Cy[0] * freq)**2 + Cy[2]**2) * dy + Cy[1] * dy**2 / z_avg * freq
            az = np.sqrt((Cz[0] * freq)**2 + Cz[2]**2) * dz + Cz[1] * dz**2 / z_avg * freq
            K = -np.sqrt(ay**2 + az**2) / (freq * meanU)
            return np.exp(K * freq)
    elif model == 'vogt':
        if Cy.size < 3 or Cz.size < 3:
            raise ValueError("Vogt requires Cy and Cz with at least three coefficients")
        ay = dy * Cy[0] * np.exp(Cy[1] * dy / z_avg)
        az = dz * Cz[0] * np.exp(Cz[1] * dz / z_avg)
        K1 = -np.sqrt(ay**2 + az**2) / meanU
        K2 = -np.sqrt(Cy[2]**2 * dy**2 + Cz[2]**2 * dz**2) / z_avg
        model_fun = lambda freq: np.exp(K1 * freq + K2)
    elif model == 'iec':
        raise NotImplementedError("IEC coherence is not implemented in the MATLAB reference function")
    else:
        raise ValueError("unknown coherence model")

    N = u.shape[0]
    if N % 2:
        raise ValueError("u must contain an even number of time steps")
    df = np.median(np.diff(f))
    k = np.arange(N)
    f2s = np.minimum(k, N - k) * df
    fftU0 = fft(u, axis=0)
    fftU = fftU0.copy()
    for ii in range(1, N // 2):
        cohU = model_fun(f2s[ii])
        try:
            C = scipy.linalg.cholesky(cohU, lower=True)
        except np.linalg.LinAlgError:
            L, D, _ = scipy.linalg.ldl(cohU, lower=True, hermitian=True)
            C = L @ scipy.linalg.sqrtm(D)
        dummy = C @ np.exp(1j * np.angle(fftU0[ii, :]))
        fftU[ii, :] = np.abs(fftU0[ii, :]) * np.exp(1j * np.angle(dummy))
        fftU[N - ii, :] = np.conj(fftU[ii, :])
    fftU[0, :] = 0
    fftU[N // 2, :] = np.real(fftU0[N // 2, :])
    return np.real(ifft(fftU, axis=0))


def write2bts(filename, u, v, w, t, y, z, zHub, uHub, ntower):
    """
    This function is a first attempt to write output from windSimFast into
    a bts file. The function write2bts is based on the function readTSgrid.m by
    Bonnie Jonkman, National Renewable Energy Laboratory
    Author: E. Cheynet  - UiB - Last modified 28/11/2022
    """
    nffc = 3
    nt = u.shape[0]
    ny = len(y)
    nz = len(z)
    dt = np.median(np.diff(t))
    dz = abs(np.median(np.diff(z)))
    dy = abs(np.median(np.diff(y)))
    coeff = 1000
    with open(filename, 'wb') as fid:
        fid.write(np.int16(8).tobytes())
        fid.write(np.int32(nz).tobytes())
        fid.write(np.int32(ny).tobytes())
        fid.write(np.int32(ntower).tobytes())
        fid.write(np.int32(nt).tobytes())
        fid.write(np.float32(dz).tobytes())
        fid.write(np.float32(dy).tobytes())
        fid.write(np.float32(dt).tobytes())
        fid.write(np.float32(uHub).tobytes())
        fid.write(np.float32(zHub).tobytes())
        fid.write(np.float32(min(z)).tobytes())
        fid.write(np.float32(coeff).tobytes())
        fid.write(np.float32(0).tobytes())
        fid.write(np.float32(coeff).tobytes())
        fid.write(np.float32(0).tobytes())
        fid.write(np.float32(coeff).tobytes())
        fid.write(np.float32(0).tobytes())
        asciiSTR = 'This full-field file was generated by windSimFaster'.encode('ascii')
        fid.write(np.int32(len(asciiSTR)).tobytes())
        fid.write(asciiSTR)
        print(f'Reading from the file {filename} with heading:')
        print(f'   "{asciiSTR.decode("ascii")}".')
        WF = np.zeros((nt, nz, ny, nffc))
        WF[:, :, :, 0] = u
        WF[:, :, :, 1] = v
        WF[:, :, :, 2] = w
        val = np.zeros(nffc, dtype=np.int16)
        for it in range(nt):
            for iz in range(nz):
                for iy in range(ny):
                    for ii in range(nffc):
                        val[ii] = np.int16(WF[it, iz, iy, ii] * coeff)
                    fid.write(val.tobytes())
